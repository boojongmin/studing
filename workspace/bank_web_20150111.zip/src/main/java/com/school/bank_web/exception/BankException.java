package com.school.bank_web.exception;

public class BankException extends RuntimeException {
	public BankException(String message){
		super(message);
	}
}
